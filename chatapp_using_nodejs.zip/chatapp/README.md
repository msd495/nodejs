# ChatApplication
This shows how to create chat application using node.js,socket.io,bootstrap,jquery.
First make one folder paste package.json there.
DO npm install,it will bring all the modules to be installed in the project.
index.html is for main GUI page
server.js is javascript file used in index.html file
To run the project ,do node Server.js
Open localhost:3000 in your browser.
In place of localhost you can give your physical IP.
In another computer or in the same computer in other tab open the same IP(i.e localhost:3000)
Finally you can chat with your friend.

pre-requisite:node.js,internet to download cdn files for jquery,boostrap(or you can download files  manually)..
